﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AssgnModels.MovieModels;

namespace AssgnModels.MovieDetails
{
    public class MovieDetailsModel : MovieModel
    {
        public ICollection<ActorList> AllActorList { get; set; }
        public ICollection<ProducerList> AllProducerList { get; set; }
        public MovieModel MovieAllDetails { get; set; }
        public ICollection<MovieActors> MovieActorsList { get; set; }
    }

    public class ActorList
    {
        public int ActorId { get; set; }
        public string ActorName { get; set; }
    }

    public class ProducerList
    {
        public int ProducerId { get; set; }
        public string ProducerName { get; set; }
    }

    public class MovieActors
    {
        public int MovieActorId {get;set;}
        public string MovieActorName{get;set;}
    }
}
