﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AssgnModels.ConnectionModels;

namespace AssgnModels.ExceptionHandling
{
    public class ExceptionLogger
    {
        public static string LogException(string errorMessage)
        {
            string Excep = errorMessage;
            using (SqlConnection conn = new SqlConnection(new ConnectionModel().ConnStr()))
            {
                SqlCommand cmd = new SqlCommand("SPERRORLOG", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar).Value = Excep;

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            return Excep;
        }
    }
}
