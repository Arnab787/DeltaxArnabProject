﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssgnModels.ProducerModels
{
    public class ProducerModel
    {
        public string ProducerName { get; set; }
        public string ProducerDob { get; set; }
        public string ProducerGender { get; set; }
        public string ProducerBio { get; set; }
    }
}
