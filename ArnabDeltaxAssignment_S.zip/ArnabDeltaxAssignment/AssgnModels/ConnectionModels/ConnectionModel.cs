﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace AssgnModels.ConnectionModels
{
    public class ConnectionModel
    {
        public static string CS;
        static ConnectionModel()
        {
            ConnectionModel.CS = ConfigurationManager.ConnectionStrings["DeltaxConnectionString"].ConnectionString;
        }

        public string ConnStr()
        {
            return CS;
        }
    }
}
