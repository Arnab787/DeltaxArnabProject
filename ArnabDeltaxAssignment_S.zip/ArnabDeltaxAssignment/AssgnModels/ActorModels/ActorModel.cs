﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssgnModels.ActorModels
{
    public class ActorModel
    {
        public string ActorName { get; set; }
        public string ActorDob { get; set; }
        public string ActorGender { get; set; }
        public string ActorBio { get; set; }
    }
}
