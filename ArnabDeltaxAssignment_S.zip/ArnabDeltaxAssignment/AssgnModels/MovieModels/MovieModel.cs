﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Threading.Tasks;

namespace AssgnModels.MovieModels
{
    public class MovieModel
    {
        public int ProducerId { get; set; }
        public string ProducerName { get; set; }
        public int MovieId { get; set; }
        public string MovieName { get; set; }
        public string MovieRelease { get; set; }
        public string MoviePlot { get; set; }
        public string MovieImagePath { get; set; }
        public string MovieImage { get; set; }
        public HttpPostedFileWrapper MovieImageFile { get; set; }
        public string[] MovieActors { get; set; }
    }
}
