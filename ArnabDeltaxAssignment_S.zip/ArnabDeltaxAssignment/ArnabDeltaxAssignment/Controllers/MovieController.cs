﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssgnModels.ProducerModels;
using AssgnModels.ActorModels;
using AssgnServices.ProducerService;
using AssgnServices.ActorService;
using AssgnServices.MovieService;
using AssgnModels.MovieDetails;
using AssgnModels.MovieModels;
using System.IO;

namespace ArnabDeltaxAssignment.Controllers
{
    public class MovieController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MoviesList()
        {
            List<MovieModel> MoviesList = new MovieService().GetMoviesList();
            return View(MoviesList);
        }

        public ActionResult MovieDetails(int MovieId)
        {
            MovieDetailsModel Movie = new MovieService().GetMovieDetails(MovieId);
            return View(Movie);
        }

        public ActionResult MovieEdit(int MovieId)
        {
            MovieDetailsModel Details = new MovieService().GetMovieDetailsNdContent(MovieId);
            return View(Details);
        }

        public ActionResult CreateMovie()
        {
            MovieDetailsModel Details = new MovieService().MovieDetais();
            return View(Details);
        }

        public ActionResult CreateProducer(ProducerModel producer)
        {
            bool Result = new ProducerService().CreateProducerService(producer);
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreateActor(ActorModel actor)
        {
            bool Result = new ActorService().CreateActorService(actor);
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreateMovieInsert(MovieModel movie)
        {
            var File = movie.MovieImageFile;
            if (File != null)
            {
                var ImgPath = Path.Combine(Server.MapPath("~/Content/images/"), movie.MovieName + "_" + File.FileName);
                File.SaveAs(ImgPath);
                movie.MovieImagePath = movie.MovieName + "_" + File.FileName;
                //File.SaveAs(Server.MapPath("~/Content/images/" + movie.MovieName + "_" + File.FileName));
                //movie.MovieImagePath = movie.MovieName + "_" + File.FileName;
            }
            else
            {
                movie.MovieImagePath = "No_Poster.png";
            }
            
            bool Result = new MovieService().CreateMovieService(movie);
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdtaeMovie(MovieModel movie)
        {
            var File = movie.MovieImageFile;
            if (File != null)
            {
                var ImgPath = Path.Combine(Server.MapPath("~/Content/images/"), movie.MovieName + "_" + File.FileName);
                File.SaveAs(ImgPath);
                movie.MovieImagePath = movie.MovieName + "_" + File.FileName;
                //File.SaveAs(Server.MapPath("~/Content/images/" + movie.MovieName + "_" + File.FileName));
                //movie.MovieImagePath = movie.MovieName + "_" + File.FileName;
            }
            else
            {
                movie.MovieImagePath = movie.MovieImage;
            }
            
            bool Result = new MovieService().UpdateMovieService(movie);
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetActor()
        {
            List<ActorList> ActorListss = new MovieService().ActorLists();
            return Json(ActorListss, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetProducer()
        {
            List<ProducerList> ProducerListss = new MovieService().ProducerLists();
            return Json(ProducerListss, JsonRequestBehavior.AllowGet);
        }

    }
}
