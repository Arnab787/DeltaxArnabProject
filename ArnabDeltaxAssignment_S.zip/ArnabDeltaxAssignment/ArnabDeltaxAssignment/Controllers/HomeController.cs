﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssgnModels.MovieModels;
using AssgnServices.MovieService;

namespace ArnabDeltaxAssignment.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MoviesIndex()
        {
            return View();
        }

        public ActionResult MovieNameList()
        {
            List<MovieModel> Movies = new MovieService().GetMoviesList();
            return Json(Movies, JsonRequestBehavior.AllowGet);
        }

    }
}
