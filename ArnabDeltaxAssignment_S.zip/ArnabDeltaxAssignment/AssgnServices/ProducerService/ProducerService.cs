﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AssgnModels.ProducerModels;
using AssgnModels.ActorModels;
using AssgnModels.ConnectionModels;
using AssgnModels.ExceptionHandling;


namespace AssgnServices.ProducerService
{
    public class ProducerService
    {
        string ConnStr = new ConnectionModel().ConnStr();
        public bool CreateProducerService(ProducerModel producer)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("SP_CREATE_PROCEDURE", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ProducerName", SqlDbType.VarChar).Value = producer.ProducerName;
                    cmd.Parameters.Add("@ProducerDob", SqlDbType.VarChar).Value = producer.ProducerDob;
                    cmd.Parameters.Add("@ProcedureSex", SqlDbType.VarChar).Value = producer.ProducerGender;
                    cmd.Parameters.Add("@ProducerBio", SqlDbType.VarChar).Value = producer.ProducerBio;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex.Message);
                return false;
            }
        }

        
    }
}
