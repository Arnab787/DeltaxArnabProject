﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AssgnModels.ActorModels;
using AssgnModels.ConnectionModels;
using AssgnModels.ExceptionHandling;


namespace AssgnServices.ActorService
{
    public class ActorService
    {
        public bool CreateActorService(ActorModel actor)
        {
            string ConnStr = new ConnectionModel().ConnStr();

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("SP_CREATE_ACTOR", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ActorName", SqlDbType.VarChar).Value = actor.ActorName;
                    cmd.Parameters.Add("@ActorDob", SqlDbType.VarChar).Value = actor.ActorDob;
                    cmd.Parameters.Add("@ActorSex", SqlDbType.VarChar).Value = actor.ActorGender;
                    cmd.Parameters.Add("@ActorBio", SqlDbType.VarChar).Value = actor.ActorBio;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex.Message);
                return false;
            }
        }
    }
}
