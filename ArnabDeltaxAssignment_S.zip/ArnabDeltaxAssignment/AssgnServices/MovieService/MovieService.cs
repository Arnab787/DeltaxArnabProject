﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using AssgnModels.MovieDetails;
using AssgnModels.ConnectionModels;
using AssgnModels.MovieModels;
using System.Globalization;
using AssgnModels.ExceptionHandling;

namespace AssgnServices.MovieService
{
    public class MovieService
    {
        string Query;
        string ConnStr = new ConnectionModel().ConnStr();

        public MovieDetailsModel MovieDetais()
        {
            MovieDetailsModel movie = new MovieDetailsModel();
            movie.AllActorList = ActorLists();
            movie.AllProducerList = ProducerLists();
            return movie;
        }
        public List<ActorList> ActorLists()
        {
            List<ActorList> ActorList = new List<ActorList>();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT actorId, actorName FROM ActorMaster ORDER BY actorName ASC";
                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ActorList actorobj = new ActorList();
                    actorobj.ActorId = Convert.ToInt32(rdr["actorId"].ToString());
                    actorobj.ActorName = rdr["actorName"].ToString();

                    ActorList.Add(actorobj);
                }
            }
            return ActorList;
        }

        public List<ProducerList> ProducerLists()
        {
            List<ProducerList> ProducerList = new List<ProducerList>();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT producerId, producerName FROM ProducerMaster ORDER BY producerName ASC";
                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ProducerList producerobj = new ProducerList();
                    producerobj.ProducerId = Convert.ToInt32(rdr["producerId"].ToString());
                    producerobj.ProducerName = rdr["producerName"].ToString();

                    ProducerList.Add(producerobj);
                }
            }
            return ProducerList;
        }

        public bool CreateMovieService(MovieModel movie)
        {
            int MovieId = 0;
            List<string> ActorsId = new List<string>();
            string UniqueId = Guid.NewGuid().ToString().Replace("-", string.Empty).Substring(0, 5);

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("SP_CREATE_MOVIE", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ProducerId", SqlDbType.VarChar).Value = movie.ProducerId;
                    cmd.Parameters.Add("@MovieName", SqlDbType.VarChar).Value = movie.MovieName;
                    cmd.Parameters.Add("@MovieRelease", SqlDbType.VarChar).Value = movie.MovieRelease;
                    cmd.Parameters.Add("@MoviePlot", SqlDbType.VarChar).Value = movie.MoviePlot;
                    cmd.Parameters.Add("@MovieImagePath", SqlDbType.VarChar).Value = movie.MovieImagePath;
                    cmd.Parameters.Add("@MovieUniqueId", SqlDbType.VarChar).Value = UniqueId;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    Query = "SELECT movieId FROM MoviesTb WHERE uniqueId='"+ UniqueId + "'";
                    SqlCommand cmd = new SqlCommand(Query, conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        MovieId = Convert.ToInt32(rdr["movieId"].ToString());
                    }
                }

                if (MovieId != 0)
                {
                    ActorsId.Clear();
                    ActorsId = movie.MovieActors[0].Split(',').Reverse().ToList();

                    foreach (var Actors in ActorsId)
                    {
                        try
                        {
                            using (SqlConnection conn = new SqlConnection(ConnStr))
                            {
                                SqlCommand cmd = new SqlCommand("SP_MOVIE_ACTORS", conn);
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.Add("@MovieId", SqlDbType.Int).Value = MovieId;
                                cmd.Parameters.Add("@ActorId", SqlDbType.Int).Value = Actors;

                                conn.Open();
                                cmd.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            ExceptionLogger.LogException(ex.Message);
                            return false;
                        }
                    }

                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex.Message);
                return false;
            }
        }

        public bool UpdateMovieService(MovieModel movie)
        {
            //int MovieId = 0;
            List<string> ActorsId = new List<string>();

            

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("SP_UPDATE_MOVIE", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ProducerId", SqlDbType.VarChar).Value = movie.ProducerId;
                    cmd.Parameters.Add("@MovieName", SqlDbType.VarChar).Value = movie.MovieName;
                    cmd.Parameters.Add("@MovieRelease", SqlDbType.VarChar).Value = movie.MovieRelease;
                    cmd.Parameters.Add("@MoviePlot", SqlDbType.VarChar).Value = movie.MoviePlot;
                    cmd.Parameters.Add("@MovieImagePath", SqlDbType.VarChar).Value = movie.MovieImagePath;
                    cmd.Parameters.Add("@MovieId", SqlDbType.VarChar).Value = movie.MovieId;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }


                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    Query = "DELETE FROM MOVIEACTORSTB WHERE movieId = " + movie.MovieId + "";
                    SqlCommand cmd = new SqlCommand(Query, conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                    ActorsId.Clear();
                    ActorsId = movie.MovieActors[0].Split(',').Reverse().ToList();

                    foreach (var Actors in ActorsId)
                    {
                        try
                        {
                            using (SqlConnection conn = new SqlConnection(ConnStr))
                            {
                                SqlCommand cmd = new SqlCommand("SP_MOVIE_ACTORS", conn);
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.Add("@MovieId", SqlDbType.Int).Value = movie.MovieId;
                                cmd.Parameters.Add("@ActorId", SqlDbType.Int).Value = Actors;

                                conn.Open();
                                cmd.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            ExceptionLogger.LogException(ex.Message);
                            return false;
                        }
                    }

                    return true;
                

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex.Message);
                return false;
            }
        }

        public List<MovieModel> GetMoviesList()
        {
            List<MovieModel> MovieList = new List<MovieModel>();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT movieId, movieName, movieImage FROM MOVIESTB ORDER BY movieName ASC";
                
                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MovieModel movieLstobj = new MovieModel();
                    movieLstobj.MovieId = Convert.ToInt32(rdr["movieId"].ToString());
                    movieLstobj.MovieName = rdr["movieName"].ToString();
                    movieLstobj.MovieImagePath = rdr["movieImage"].ToString();

                    MovieList.Add(movieLstobj);
                }
            }
            return MovieList;
        }

        public MovieDetailsModel GetMovieDetails(int MovieId)
        {
            MovieDetailsModel MainMovieObj = new MovieDetailsModel();
            
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT M.movieId, M.movieName, M.producerId, P.producerName, M.movieReleaseYear, M.moviePlot, M.movieImage FROM MOVIESTB M, PRODUCERMASTER P WHERE M.producerId = P.producerId AND M.movieId = " + MovieId + "";

                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    MainMovieObj.MovieId = Convert.ToInt32(rdr["movieId"].ToString());
                    MainMovieObj.MovieName = rdr["movieName"].ToString();
                    MainMovieObj.ProducerId = Convert.ToInt32(rdr["producerId"].ToString());
                    MainMovieObj.ProducerName = rdr["producerName"].ToString();
                    MainMovieObj.MovieRelease = rdr["movieReleaseYear"].ToString();
                    MainMovieObj.MoviePlot = rdr["moviePlot"].ToString();
                    MainMovieObj.MovieImagePath = rdr["movieImage"].ToString();
                }
            }
            MainMovieObj.MovieActorsList = GetMovieActors(MovieId);
            

            return MainMovieObj;

        }

        public MovieDetailsModel GetMovieDetailsNdContent(int MovieId)
        {
            MovieDetailsModel MainMovieObj = new MovieDetailsModel();

            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT M.movieId, M.movieName, M.producerId, P.producerName, M.movieReleaseYear, M.moviePlot, M.movieImage FROM MOVIESTB M, PRODUCERMASTER P WHERE M.producerId = P.producerId AND M.movieId = " + MovieId + "";

                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    MainMovieObj.MovieId = Convert.ToInt32(rdr["movieId"].ToString());
                    MainMovieObj.MovieName = rdr["movieName"].ToString();
                    MainMovieObj.ProducerId = Convert.ToInt32(rdr["producerId"].ToString());
                    MainMovieObj.ProducerName = rdr["producerName"].ToString();
                    MainMovieObj.MovieRelease = rdr["movieReleaseYear"].ToString();
                    MainMovieObj.MoviePlot = rdr["moviePlot"].ToString();
                    MainMovieObj.MovieImagePath = rdr["movieImage"].ToString();
                }
            }
            MainMovieObj.MovieActorsList = GetMovieActors(MovieId);
            MainMovieObj.AllActorList = ActorLists();
            MainMovieObj.AllProducerList = ProducerLists();

            return MainMovieObj;
        }

        public List<MovieActors> GetMovieActors(int MovieId)
        {
            List<MovieActors> MovieActorList = new List<MovieActors>();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                Query = "SELECT M.movieId, M.actorId, A.actorName FROM MOVIEACTORSTB M, ACTORMASTER A WHERE M.actorId = A.actorId AND M.movieId = "+MovieId+ " ORDER BY A.actorName ASC";

                SqlCommand cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MovieActors movieactorLstobj = new MovieActors();
                    movieactorLstobj.MovieActorId = Convert.ToInt32(rdr["actorId"].ToString());
                    movieactorLstobj.MovieActorName = rdr["actorName"].ToString();

                    MovieActorList.Add(movieactorLstobj);
                }
            }
            return MovieActorList;
        }

    }
}
